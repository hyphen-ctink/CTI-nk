# backend-test

팀원 백엔드 이미지가 아직 없을 때만 쓰는 테스트용 backend image 생성 폴더다.

사용법:

```bash
cp /path/to/detection_rule_deployer.py ./detection_rule_deployer.py
docker build -t ctink-backend:latest .
```

이 이미지는 룰 파일 추가/삭제 테스트만 한다.

```text
/shared/rules/snort/local.rules
/shared/rules/yara/ctink_rules.yar
```
