#!/usr/bin/env python3

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Set


YARA_RULE_FILE = os.getenv("YARA_RULE_FILE", "/opt/ctink/yara/rules/ctink_rules.yar")
YARA_SCAN_TARGET = os.getenv("YARA_SCAN_TARGET", "/scan_target/downloads")
YARA_LOG_FILE = os.getenv("YARA_LOG_FILE", "/var/log/ctink/yara_scan.log")
SCAN_INTERVAL = int(os.getenv("YARA_SCAN_INTERVAL_SEC", "30"))

ERROR_LOG_FILE = "/var/log/ctink/yara_scanner_error.log"
SEEN_FILE = "/var/log/ctink/.yara_seen.json"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _write_error(message: str) -> None:
    line = f"{_now()} {message}"
    print(line, flush=True)
    try:
        Path(ERROR_LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
        with open(ERROR_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def _load_seen() -> Set[str]:
    try:
        with open(SEEN_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return set(str(x) for x in data)
    except Exception:
        pass
    return set()


def _save_seen(seen: Set[str]) -> None:
    try:
        Path(SEEN_FILE).parent.mkdir(parents=True, exist_ok=True)
        tmp_path = f"{SEEN_FILE}.tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(sorted(seen), f, ensure_ascii=False)
        os.replace(tmp_path, SEEN_FILE)
    except Exception as exc:
        _write_error(f"[yara] failed to save seen cache: {exc}")


def _append_detection(event: Dict[str, object]) -> None:
    Path(YARA_LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
    with open(YARA_LOG_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def _rule_file_ready() -> bool:
    p = Path(YARA_RULE_FILE)
    return p.exists() and p.is_file() and p.stat().st_size > 0


def _target_ready() -> bool:
    p = Path(YARA_SCAN_TARGET)
    return p.exists() and p.is_dir()


def _scan_once(seen: Set[str]) -> None:
    if not _rule_file_ready():
        _write_error(f"[yara] rule file missing or empty, waiting: {YARA_RULE_FILE}")
        return

    if not _target_ready():
        _write_error(f"[yara] scan target missing, waiting: {YARA_SCAN_TARGET}")
        return

    cmd = [
        "yara",
        "-r",
        YARA_RULE_FILE,
        YARA_SCAN_TARGET,
    ]

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=max(30, SCAN_INTERVAL),
        )
    except subprocess.TimeoutExpired:
        _write_error("[yara] scan timeout")
        return
    except Exception as exc:
        _write_error(f"[yara] scan error: {exc}")
        return

    if proc.stderr.strip():
        _write_error(f"[yara] stderr: {proc.stderr.strip()}")

    stdout = proc.stdout or ""

    for raw_line in stdout.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        if " " in line:
            rule_name, target_path = line.split(" ", 1)
        else:
            rule_name, target_path = line, ""

        event_key = f"{rule_name}|{target_path}|{line}"

        if event_key in seen:
            continue

        seen.add(event_key)

        event = {
            "timestamp": _now(),
            "engine": "yara",
            "rule_name": rule_name,
            "target_path": target_path,
            "raw_output": line,
            "rule_file": YARA_RULE_FILE,
            "scan_target": YARA_SCAN_TARGET,
        }

        _append_detection(event)


def main() -> None:
    Path(YARA_LOG_FILE).parent.mkdir(parents=True, exist_ok=True)
    seen = _load_seen()

    _write_error("[yara] scanner started")
    _write_error(f"[yara] rule file: {YARA_RULE_FILE}")
    _write_error(f"[yara] scan target: {YARA_SCAN_TARGET}")
    _write_error(f"[yara] interval: {SCAN_INTERVAL}s")

    while True:
        _scan_once(seen)
        _save_seen(seen)
        time.sleep(SCAN_INTERVAL)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as exc:
        _write_error(f"[yara] fatal error: {exc}")
        sys.exit(1)
