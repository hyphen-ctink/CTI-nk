#!/usr/bin/env python3

import hashlib
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


SNORT_CONF = os.getenv("SNORT_CONF", "/etc/snort/snort.conf")
SNORT_RULE_FILE = os.getenv("SNORT_RULE_FILE", "/etc/snort/rules/local.rules")
SNORT_LOG_DIR = os.getenv("SNORT_LOG_DIR", "/var/log/snort")
SNORT_INTERFACE_ENV = os.getenv("SNORT_INTERFACE", "auto")
WATCH_INTERVAL = int(os.getenv("RULE_WATCH_INTERVAL_SEC", "10"))

RUNNER_LOG = "/var/log/ctink/rule_watcher.log"

snort_proc: Optional[subprocess.Popen] = None
stop_requested = False


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _log(message: str) -> None:
    line = f"{_now()} {message}"
    print(line, flush=True)
    try:
        Path(RUNNER_LOG).parent.mkdir(parents=True, exist_ok=True)
        with open(RUNNER_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def _run_stdout(cmd: list[str]) -> str:
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if proc.returncode == 0:
            return proc.stdout.strip()
    except Exception:
        pass
    return ""


def _detect_default_interface() -> str:
    """
    SNORT_INTERFACE=auto일 때 컨테이너 내부에서 실제 캡처 인터페이스를 고른다.

    우선순위:
    1. ip route get 8.8.8.8 결과의 dev
    2. ip route show default 결과의 dev
    3. /sys/class/net에서 lo/docker/br/veth를 제외한 첫 번째 인터페이스
    4. eth0 fallback

    any는 Snort 환경에 따라 data link type 113 오류가 날 수 있어서 기본값으로 쓰지 않는다.
    """
    out = _run_stdout(["ip", "route", "get", "8.8.8.8"])
    parts = out.split()

    if "dev" in parts:
        idx = parts.index("dev")
        if idx + 1 < len(parts):
            return parts[idx + 1]

    out = _run_stdout(["ip", "route", "show", "default"])
    parts = out.split()

    if "dev" in parts:
        idx = parts.index("dev")
        if idx + 1 < len(parts):
            return parts[idx + 1]

    try:
        names = sorted(p.name for p in Path("/sys/class/net").iterdir())
        for name in names:
            if name == "lo":
                continue
            if name.startswith(("docker", "br-", "veth")):
                continue
            return name
    except Exception:
        pass

    return "eth0"


def _snort_interface() -> str:
    value = (SNORT_INTERFACE_ENV or "auto").strip()

    if value.lower() == "auto":
        detected = _detect_default_interface()
        _log(f"[snort] SNORT_INTERFACE=auto, detected interface: {detected}")
        return detected

    return value


def _sha256_file(path: str) -> Optional[str]:
    p = Path(path)
    if not p.exists() or not p.is_file():
        return None

    h = hashlib.sha256()
    try:
        with open(p, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception as exc:
        _log(f"[rule_watcher] failed to hash {path}: {exc}")
        return None


def _start_snort() -> None:
    global snort_proc

    if snort_proc is not None and snort_proc.poll() is None:
        return

    if not Path(SNORT_RULE_FILE).exists():
        _log(f"[snort] rule file not found, waiting: {SNORT_RULE_FILE}")
        return

    Path(SNORT_LOG_DIR).mkdir(parents=True, exist_ok=True)

    interface = _snort_interface()

    cmd = [
        "snort",
        "-A",
        "fast",
        "-q",
        "-c",
        SNORT_CONF,
        "-i",
        interface,
        "-l",
        SNORT_LOG_DIR,
    ]

    try:
        log_path = Path("/var/log/ctink/snort_process.log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = open(log_path, "a", encoding="utf-8")

        _log(f"[snort] starting: {' '.join(cmd)}")
        snort_proc = subprocess.Popen(
            cmd,
            stdout=log_file,
            stderr=log_file,
            text=True,
        )
    except Exception as exc:
        _log(f"[snort] failed to start: {exc}")
        snort_proc = None


def _stop_snort() -> None:
    global snort_proc

    if snort_proc is None:
        return

    if snort_proc.poll() is not None:
        snort_proc = None
        return

    _log("[snort] stopping")
    try:
        snort_proc.terminate()
        snort_proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        _log("[snort] terminate timeout, killing")
        snort_proc.kill()
        snort_proc.wait(timeout=5)
    except Exception as exc:
        _log(f"[snort] stop error: {exc}")
    finally:
        snort_proc = None


def _restart_snort(reason: str) -> None:
    _log(f"[snort] restarting because {reason}")
    _stop_snort()
    time.sleep(1)
    _start_snort()


def _handle_signal(signum, frame) -> None:
    global stop_requested
    _log(f"[rule_watcher] received signal {signum}")
    stop_requested = True
    _stop_snort()


def main() -> None:
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    _log("[rule_watcher] started")
    _log(f"[rule_watcher] watching: {SNORT_RULE_FILE}")
    _log(f"[rule_watcher] interval: {WATCH_INTERVAL}s")
    _log(f"[rule_watcher] SNORT_INTERFACE env: {SNORT_INTERFACE_ENV}")

    last_hash = _sha256_file(SNORT_RULE_FILE)

    if last_hash is None:
        _log("[rule_watcher] initial rule hash is empty because file does not exist yet")
    else:
        _log(f"[rule_watcher] initial snort rule hash: {last_hash}")

    _start_snort()

    last_unexpected_exit_log = 0.0

    while not stop_requested:
        current_hash = _sha256_file(SNORT_RULE_FILE)

        if current_hash != last_hash:
            _log(f"[rule_watcher] snort rule changed: {last_hash} -> {current_hash}")
            last_hash = current_hash
            _restart_snort("snort rule file changed")

        if snort_proc is None or snort_proc.poll() is not None:
            now = time.time()
            if now - last_unexpected_exit_log >= 10:
                exit_code = None if snort_proc is None else snort_proc.poll()
                _log(f"[snort] not running, exit_code={exit_code}, trying to start")
                last_unexpected_exit_log = now
            _start_snort()

        time.sleep(WATCH_INTERVAL)

    _stop_snort()
    _log("[rule_watcher] stopped")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        _log(f"[rule_watcher] fatal error: {exc}")
        sys.exit(1)
