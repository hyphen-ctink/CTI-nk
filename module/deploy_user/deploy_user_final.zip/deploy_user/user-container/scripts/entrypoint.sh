#!/usr/bin/env bash
set -euo pipefail

mkdir -p /var/log/snort
mkdir -p /var/log/ctink
mkdir -p /scan_target/downloads

touch /var/log/snort/alert || true
touch /var/log/ctink/yara_scan.log || true
touch /var/log/ctink/rule_watcher.log || true
touch /var/log/ctink/snort_process.log || true
touch /var/log/ctink/yara_scanner_error.log || true

echo "[ctink-user] starting rule_watcher.py"
python3 -u /opt/ctink/scripts/rule_watcher.py &
RULE_WATCHER_PID="$!"

echo "[ctink-user] starting yara_scanner.py"
python3 -u /opt/ctink/scripts/yara_scanner.py &
YARA_SCANNER_PID="$!"

_term() {
  echo "[ctink-user] stopping child processes"
  kill "$RULE_WATCHER_PID" "$YARA_SCANNER_PID" 2>/dev/null || true
  wait "$RULE_WATCHER_PID" "$YARA_SCANNER_PID" 2>/dev/null || true
}

trap _term TERM INT

wait -n "$RULE_WATCHER_PID" "$YARA_SCANNER_PID"
EXIT_CODE="$?"

_term
exit "$EXIT_CODE"
