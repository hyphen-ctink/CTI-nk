#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

echo "[+] CTI-nk deploy_user install start"

if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
  REAL_USER="$SUDO_USER"
else
  REAL_USER="$(id -un)"
fi

REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"

if [ -z "$REAL_HOME" ] || [ ! -d "$REAL_HOME" ]; then
  echo "[!] Cannot resolve home directory for user: $REAL_USER"
  exit 1
fi

HOST_DOWNLOADS_DIR="$REAL_HOME/Downloads"
mkdir -p "$HOST_DOWNLOADS_DIR"

if ! command -v docker >/dev/null 2>&1; then
  echo "[!] docker command not found."
  echo "[!] Install Docker first, then run this script again."
  exit 1
fi

if docker compose version >/dev/null 2>&1; then
  COMPOSE_CMD="docker compose"
elif command -v docker-compose >/dev/null 2>&1; then
  COMPOSE_CMD="docker-compose"
else
  echo "[!] Docker Compose not found."
  echo "[!] Install Docker Compose plugin first."
  exit 1
fi

if [ ! -f ".env" ]; then
  cat > .env <<EOF
HOST_DOWNLOADS_DIR=$HOST_DOWNLOADS_DIR
SNORT_INTERFACE=auto
RULE_WATCH_INTERVAL_SEC=10
YARA_SCAN_INTERVAL_SEC=30
RABBITMQ_URL=amqp://guest:guest@localhost:5672/%2F
RULE_DEPLOY_APPLY_QUEUE=rule_deploy_apply
RULE_DEPLOY_REMOVE_QUEUE=rule_deploy_remove
MYSQL_DATABASE=ctink
MYSQL_USER=ctink
MYSQL_PASSWORD=ctink_password
MYSQL_ROOT_PASSWORD=root_password
EOF
  echo "[+] Created .env"
else
  echo "[*] .env already exists. Keeping existing .env"
  echo "[*] If Snort still uses any, edit .env manually:"
  echo "    SNORT_INTERFACE=auto"
fi

echo "[+] HOST_DOWNLOADS_DIR=$HOST_DOWNLOADS_DIR"

if command -v systemctl >/dev/null 2>&1; then
  sudo systemctl enable --now docker || true
fi

echo "[+] Creating and initializing Docker named volumes"

docker volume create ctink_snort_rules >/dev/null
docker volume create ctink_yara_rules >/dev/null
docker volume create ctink_snort_logs >/dev/null
docker volume create ctink_yara_logs >/dev/null
docker volume create ctink_db_data >/dev/null

docker run --rm -v ctink_snort_rules:/v busybox sh -c 'touch /v/local.rules'
docker run --rm -v ctink_yara_rules:/v busybox sh -c 'touch /v/ctink_rules.yar'
docker run --rm -v ctink_snort_logs:/v busybox sh -c 'touch /v/alert'
docker run --rm -v ctink_yara_logs:/v busybox sh -c 'touch /v/yara_scan.log'

echo "[+] Starting containers"
$COMPOSE_CMD up -d --build

echo "[+] Done"
echo "[+] Check containers:"
echo "    $COMPOSE_CMD ps"
echo "[+] Check user-container logs:"
echo "    docker logs -f ctink-user"
echo "[+] Downloads mounted from:"
echo "    $HOST_DOWNLOADS_DIR"
